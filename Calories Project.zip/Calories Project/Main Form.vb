﻿' Name:         Calories Project
' Purpose:      Display calorie information.
' Programmer:   Marco Gomez on 7/10/2019

Option Explicit On
Option Strict On
Option Infer Off

Public Class frmMain
   Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnDisplay_Click(sender As Object, e As EventArgs) Handles btnDisplay.Click
        ' Display calorie information.

        'Array of the amount of calories consumed through out the days
        Dim intCalories() As Integer = {2250, 1920, 2125, 2505, 2010, 1950, 1825,
                                        2025, 2000, 1820, 1990, 1950, 1875, 1750}

        'Scope for variables used for calulating average consumption and days below, above, or at that average.
        Dim avgAbove As Integer = 0
        Dim avgBelow As Integer = 0
        Dim avgDays As Integer = 0
        Dim AvgConsume As Integer

        'Iterrates through array and adds each value to the AvgConsume variable
        For i As Integer = 0 To intCalories.Length - 1
            AvgConsume = AvgConsume + intCalories(i)
        Next i

        'Take AvgConsume as total sum of the consumed calories and then divides it by the
        'number of days the caloric intake was recorded. This becomes the average amount of calories
        AvgConsume = CInt(Math.Round(AvgConsume / intCalories.Count))

        'Iterrates through the array of calories consumed and counts how many days were above, below,
        'or at the average consumption.
        For i As Integer = 0 To intCalories.Length - 1
            If intCalories(i) > AvgConsume Then
                avgAbove += 1
            ElseIf intCalories(i) < AvgConsume Then
                avgBelow += 1
            Else
                avgDays += 1
            End If
        Next i

        'Outputs each variable as a text to its corresponding tex boxes.
        lblAvg.Text = Convert.ToString(AvgConsume)
        lblAtAvg.Text = Convert.ToString(avgDays)
        lblAboveAvg.Text = Convert.ToString(avgAbove)
        lblBelowAvg.Text = Convert.ToString(avgBelow)
    End Sub
End Class
